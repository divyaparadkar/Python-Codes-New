#Ratio and propotional queation



#find a:b:c
a=2
b=3
c=3
d=4
n=a*b,b*c,c*d

print(n[0],":",n[1],":",n[2])

#find out the 4th propotional of the value
'''a=4
b=6
c=124
d= b*c/a
print(d)'''

#find out the third propotional of the value
'''a= 18
b=54
c=b*b*a

print(c)'''

#find the greater ratio

'''print("Enter the value of a:")
a=int(input())
print("Enter the value of b:")
b= int(input())
print("Enter the value of c")
c= int(input())
print("Enter the value of d")
d=int(input())
if (a*c>b*c):
    print("a:b is greater than b:c")
else:
    print("b:c is greater than a:c")'''

# find the greater ratio of three no.

